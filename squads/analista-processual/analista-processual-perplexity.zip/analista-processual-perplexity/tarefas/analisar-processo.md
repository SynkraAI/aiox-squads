# Tarefa: *analisar-processo

## Fluxo de Execução — Análise Completa de Processo Judicial

**Executor:** analista-processual (com apoio de extrator-documentos, calculador-prazos, mapeador-riscos)
**Modo:** Sequencial — 5 fases
**Output:** Relatório de Análise Processual

---

## Inputs Necessários

```
processo:    Número do processo (formato CNJ ou livre)
documentos:  Texto ou conteúdo das peças processuais
tribunal:    Tribunal/vara (opcional — extraído do documento se disponível)
objetivo:    Foco da análise (opcional — padrão: análise completa)
```

## Elicitação Automática

```
1. Qual o número do processo?
   > [usuário informa]

2. Cole ou descreva os documentos a analisar (petição inicial, decisão, etc.):
   > [usuário fornece]

3. Há algum foco específico? (prazos, riscos, partes, resumo executivo)
   > [usuário responde ou "análise completa"]
```

---

## Fases de Execução

### Fase 1 — Identificação
1. Extrair número do processo no formato CNJ
2. Identificar: tribunal, vara/câmara, instância, classe processual
3. Identificar fase processual atual

### Fase 2 — Extração de Dados
1. Identificar tipo de cada documento fornecido
2. Extrair partes (polo ativo, passivo, advogados, OAB)
3. Extrair objeto da ação (pedidos + fundamentos jurídicos)
4. Extrair cronologia de atos processuais com datas
5. Extrair citações legais e jurisprudenciais

### Fase 3 — Cálculo de Prazos
1. Identificar o último ato intimado e a data de intimação
2. Calcular prazos correntes (CPC/2015 = dias úteis)
3. Identificar prazos fatais (< 3 dias úteis = CRÍTICO)
4. Gerar tabela de prazos com datas-limite

### Fase 4 — Mapeamento de Riscos
1. Verificar pressupostos processuais (5 níveis)
2. Verificar competência absoluta e relativa
3. Analisar prescrição/decadência
4. Identificar nulidades e vícios formais
5. Classificar riscos: CRÍTICO | ATENÇÃO | OBSERVAÇÃO

### Fase 5 — Síntese e Relatório
1. Consolidar dados das fases anteriores
2. Ordenar alertas por criticidade (CRÍTICO primeiro)
3. Entregar relatório no formato padrão

---

## Condições de Veto

- NUNCA iniciar análise sem ao menos o número do processo ou a peça processual
- SE documentos insuficientes: alertar e listar o que está faltando
- SE prazo CRÍTICO identificado: destacar no INÍCIO do relatório

---

## Output Esperado

Ver template: `templates/relatorio-analise-processual.md`
