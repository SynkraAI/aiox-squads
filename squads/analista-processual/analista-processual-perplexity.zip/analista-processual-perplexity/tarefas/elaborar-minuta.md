# Tarefa: *contestacao / *recurso / *manifestacao / *peticao-inicial

## Fluxo de Execução — Elaboração de Minutas de Peças Processuais

**Executor:** analista-processual
**Modo:** Interativo + geração
**Output:** Minuta de peça processual

---

## Aviso Obrigatório

> ⚠️ A minuta é um **rascunho** para uso interno.
> Toda peça processual elaborada pelo squad deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.

---

## Fluxo para Qualquer Minuta

1. **Verificar prazo** — Se for recurso, calcular se ainda há prazo. Alertar se < 3 dias úteis.
2. **Elicitar informações** — Perguntar o que não consta nos documentos fornecidos
3. **Carregar contexto** — Usar análise do processo como base
4. **Elaborar minuta** — Seguir estrutura padrão (CPC/2015)
5. **Sinalizar pontos** — Marcar o que o advogado deve revisar/completar
6. **Entregar** — Com aviso de rascunho

---

## Elicitação por Tipo de Peça

### Para Contestação
```
1. O réu tem preliminares a arguir? (incompetência, ilegitimidade, etc.)
2. Quais são os principais fatos impugnados?
3. Qual a tese jurídica principal do réu?
4. Há reconvenção a apresentar?
5. Quais provas serão requeridas?
```

### Para Apelação
```
1. Por que a sentença deve ser reformada? (quais os erros)
2. Há fundamentos jurídicos específicos para invocar?
3. Há jurisprudência favorável conhecida?
4. O preparo já foi recolhido?
```

### Para Embargos de Declaração
```
1. Qual é o vício: omissão, contradição, obscuridade ou erro material?
2. Qual o trecho da decisão que apresenta o vício?
3. O que o embargante pretende com o vício sanado?
4. Busca efeito infringente (modificar o resultado)?
```

### Para Agravo de Instrumento
```
1. Qual decisão está sendo agravada?
2. Em qual inciso do art. 1.015 se enquadra?
3. Há urgência para requerer efeito suspensivo?
```

---

## Marcadores de Sinalização na Minuta

| Marcador | Uso |
|----------|-----|
| `⚠️ REVISAR:` | Ponto que o advogado deve verificar/adaptar |
| `📋 COMPLETAR:` | Informação ausente que deve ser inserida |
| `⚖️ ESTRATÉGIA:` | Decisão estratégica — múltiplas abordagens possíveis |
| `📄 DOCUMENTO:` | Documento que deve ser juntado em anexo |

---

## Estruturas Padrão

### Contestação (art. 335-342, CPC/2015)
```
I.   Qualificação do réu
II.  Preliminares (se cabíveis)
III. No mérito
     3.1 Impugnação dos fatos
     3.2 Fundamentos jurídicos
     3.3 Jurisprudência favorável
IV.  Reconvenção (se cabível)
V.   Dos pedidos
VI.  Requerimentos
```

### Apelação (art. 1.009-1.014, CPC/2015)
```
I.   Tempestividade
II.  Cabimento e legitimidade
III. Preparo
IV.  Dos fatos e da decisão recorrida
V.   Razões de reforma
VI.  Jurisprudência favorável
VII. Do pedido
```

### Embargos de Declaração (art. 1.022-1.026, CPC/2015)
```
I.   Tempestividade (5 dias úteis)
II.  Do vício apontado (omissão/contradição/obscuridade/erro)
III. Do pedido (sanação do vício ± efeito infringente)
```

### Agravo de Instrumento (art. 1.015-1.020, CPC/2015)
```
I.   Cabimento (rol taxativo do art. 1.015)
II.  Tempestividade
III. Da decisão agravada
IV.  Da urgência (se efeito suspensivo)
V.   Razões de reforma
VI.  Do pedido
```

---

## Condições de Veto

- NUNCA apresentar minuta como peça final — sempre como rascunho
- SEMPRE verificar prazo antes de elaborar recurso
- SEMPRE verificar cabimento do agravo (rol taxativo do art. 1.015)

---

## Templates Disponíveis

- `templates/minutas/contestacao.md`
- `templates/minutas/apelacao.md`
- `templates/minutas/embargos-declaracao.md`
- `templates/minutas/agravo-instrumento.md`
- `templates/minutas/manifestacao.md`
