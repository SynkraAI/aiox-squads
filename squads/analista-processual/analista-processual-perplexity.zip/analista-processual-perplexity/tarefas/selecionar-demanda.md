# Tarefa: *selecionar-demanda

## Fluxo de Execução — Seleção de Demanda Ativa

**Executor:** navegador-arquivos (acionado automaticamente ao iniciar sessão)
**Trigger:** Automático ao ativar o squad

---

## Objetivo

Definir em qual demanda/processo o squad vai focar na sessão atual, garantindo que todos os outputs sejam contextualizados para a demanda correta.

---

## Modo com Google Drive (ambiente original)

1. Ler pasta `K:\Meu Drive\Processos_Judiciais_IA\`
2. Listar 10 mais recentes (ordenadas por data de modificação)
3. Perguntar ao usuário qual demanda trabalhar
4. Confirmar seleção
5. Registrar demanda ativa no contexto da sessão

---

## Modo no Perplexity (sem Google Drive)

**Como o Perplexity não tem acesso ao sistema de arquivos, usar este fluxo adaptado:**

### Passo 1 — Solicitar ao usuário
```
Para iniciar a sessão, informe:

1. Nome da demanda ativa:
   > [Ex: "3. Mandado de Segurança — Licitação"]

2. Documentos a analisar nesta sessão:
   > [Cole o texto ou descreva os documentos disponíveis]
```

### Passo 2 — Confirmar e registrar
```
✅ Demanda ativa: {nome informado pelo usuário}

Documentos disponíveis nesta sessão:
  - {lista de documentos fornecidos}

Squad configurado. Próximos passos:
  *analisar-processo  *mapear-prazos  *resumir-processo
  *analisar-sentenca  *riscos         *contestacao
```

---

## Condição de Veto

- NUNCA iniciar análise sem demanda ativa confirmada
- SEMPRE registrar a demanda no cabeçalho de todos os relatórios
