# Tarefa: *analisar-sentenca

## Fluxo de Execução — Análise Estruturada de Sentença

**Executor:** analista-processual
**Modo:** Single-pass
**Output:** Análise estruturada da sentença

---

## Objetivo

Estruturar e analisar a sentença em suas três partes obrigatórias (art. 489, CPC/2015), identificar o resultado para cada parte, prazos recursais e pontos relevantes para estratégia recursal.

## Input Necessário

```
sentenca: Texto completo da sentença
processo: Número do processo (opcional — extraído do documento)
```

---

## Passos de Execução

1. Identificar as três partes da sentença (art. 489, CPC/2015):
   - Relatório
   - Fundamentação
   - Dispositivo

2. Extrair o dispositivo: procedência parcial / total / improcedência / extinção sem mérito

3. Mapear cada pedido vs. resultado obtido

4. Identificar condenações: valor, juros, correção monetária, honorários, custas

5. Resumir os fundamentos jurídicos centrais da decisão

6. Calcular prazos recursais:
   - **Embargos de declaração:** 5 dias úteis (art. 1.023, CPC/2015)
   - **Apelação:** 15 dias úteis (art. 1.003, §5º, CPC/2015)

7. Identificar pontos passíveis de recurso:
   - Para embargos: omissão, contradição, obscuridade, erro material (art. 1.022)
   - Para apelação: aspectos favoráveis à revisão em 2º grau

---

## Regras de Qualidade

- NUNCA omitir o dispositivo — é o elemento mais importante
- SEMPRE calcular o prazo para embargos (5 dias úteis) mesmo que a parte não pretenda recorrer
- SE sentença omissa sobre algum pedido: sinalizar como PONTO DE ATENÇÃO para embargos
- SE condenação em honorários: especificar base de cálculo e percentual

---

## Output Esperado

Ver template: `templates/analise-sentenca.md`
