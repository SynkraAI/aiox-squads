# Tarefa: *mapear-prazos

## Fluxo de Execução — Mapeamento Completo de Prazos Processuais

**Executor:** calculador-prazos
**Modo:** Single-pass
**Output:** Tabela de prazos com alertas de urgência

---

## Inputs Necessários

```
processo:    Número do processo
ultimo_ato:  Data e descrição do último ato intimado
tribunal:    Tribunal (para considerar calendário local)
documentos:  Peças que geraram prazos (decisão, despacho, citação, etc.)
```

## Elicitação Automática

```
1. Qual o número do processo?
2. Qual foi o último ato e quando foi intimado/publicado?
3. Em qual tribunal tramita o processo?
4. Cole o documento que gerou o prazo (se tiver):
```

---

## Passos de Execução

1. Identificar todos os atos que geraram ou gerarão prazos
2. Para cada ato: aplicar prazo legal (CPC/2015 ou lei especial)
3. Calcular data-início (D+1 útil após intimação — art. 224)
4. Calcular data-limite (dias úteis — art. 219)
5. Classificar urgência por dias úteis restantes
6. Ordenar por urgência crescente (mais urgente primeiro)

---

## Classificação de Urgência

| Nível | Dias Úteis Restantes |
|-------|---------------------|
| ⬛ VENCIDO | 0 ou negativo |
| 🔴 CRÍTICO | 1 a 3 dias úteis |
| 🟡 URGENTE | 4 a 5 dias úteis |
| 🟠 ATENÇÃO | 6 a 10 dias úteis |
| 🟢 OK | mais de 10 dias úteis |
| ✅ CUMPRIDO | ato já praticado |

---

## Condições de Veto

- NUNCA calcular prazo sem identificar a data de intimação/publicação
- SE não houver informação de feriados locais: alertar que o cálculo pode divergir
- SE prazo já vencido: destacar como VENCIDO e orientar verificação imediata

---

## Output Esperado

Ver template: `templates/relatorio-prazos.md`
