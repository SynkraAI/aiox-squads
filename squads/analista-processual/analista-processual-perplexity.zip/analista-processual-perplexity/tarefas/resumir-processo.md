# Tarefa: *resumir-processo

## Fluxo de Execução — Resumo Executivo

**Executor:** analista-processual
**Modo:** Single-pass
**Output:** Resumo executivo de 1 página

---

## Objetivo

Resumo conciso (1-2 páginas) para leitura rápida por advogados e gestores jurídicos.
Foco: quem, o que pede, onde está, prazos imediatos e riscos.

## Inputs Necessários

```
processo:      Número do processo
documentos:    Peça(s) processual(is) a resumir
destinatario:  (opcional) advogado | gestor | cliente
```

---

## As 5 Informações Essenciais

1. **Quem** são as partes
2. **O que** se discute (objeto)
3. **Onde está** (fase/instância)
4. **Quais prazos** correm agora
5. **Quais os riscos** imediatos

---

## Regras de Qualidade

- Resumo completo em no máximo 1 página impressa
- Proibido: parágrafos longos, jargão sem explicação, omitir prazos ativos
- Obrigatório: data do resumo, número do processo, flag de urgência se houver prazo < 5 dias

---

## Output Esperado

Ver template: `templates/resumo-executivo.md`
