# Template — Relatório de Análise Processual

> Analista Processual Squad v1.1.0
> Instrução: Preencha substituindo os campos entre {chaves}. Remova seções não aplicáveis.

---

```markdown
# Relatório de Análise Processual

**Processo:** {número CNJ — NNNNNNN-DD.AAAA.J.TT.OOOO}
**Tribunal/Vara:** {nome do tribunal} — {nome da vara ou câmara}
**Instância:** {1º grau | 2º grau | STJ | STF}
**Classe:** {classe processual CNJ}
**Fase atual:** {distribuição | citação | instrução | sentença | recurso | execução}
**Análise gerada em:** {DD/MM/AAAA}
**Demanda:** {nome da pasta da demanda ativa}

---

⚠️ ALERTAS CRÍTICOS
{Preencher APENAS se houver prazos ou riscos CRÍTICOS — este bloco vai antes de qualquer dado}
{Se não houver alertas críticos, remover esta seção}

---

## 1. Identificação do Processo

| Campo | Dado |
|-------|------|
| Número (CNJ) | {NNNNNNN-DD.AAAA.J.TT.OOOO} |
| Tribunal | {nome do tribunal} |
| Vara/Câmara | {identificação da vara ou câmara} |
| Juiz/Relator | {nome ou "Não identificado"} |
| Distribuído em | {DD/MM/AAAA ou "Não identificado"} |
| Classe processual | {classe CNJ} |
| Assunto CNJ | {assunto ou "Não identificado"} |
| Fase atual | {fase processual} |

---

## 2. Partes

| Polo | Nome | CPF/CNPJ | Advogado | OAB |
|------|------|----------|----------|-----|
| Ativo (Autor/Requerente) | {nome} | {CPF/CNPJ} | {nome} | {OAB/XX NNNNN} |
| Passivo (Réu/Requerido) | {nome} | {CPF/CNPJ} | {nome} | {OAB/XX NNNNN} |
| Terceiro (se houver) | {nome} | {CPF/CNPJ} | {nome} | {OAB/XX NNNNN} |

---

## 3. Objeto da Ação

**Tipo de ação:** {denominação da ação}
**Rito:** {Procedimento Comum | Sumário | Especial | JEC | Trabalhista}

**Pedido principal:**
{descrever o pedido principal em 1-3 linhas}

**Pedidos subsidiários/cumulados:**
1. {pedido}
2. {pedido}
3. {pedido}

**Fundamentos jurídicos invocados:**
- {artigo/lei/princípio}
- {artigo/lei/princípio}

**Valor da causa:** R$ {valor}

---

## 4. Cronologia Processual

| Data | Ato | Responsável | Prazo Gerado |
|------|-----|-------------|-------------|
| {DD/MM/AAAA} | Distribuição da ação | Autor | — |
| {DD/MM/AAAA} | Citação do réu | Juízo | Contestação: {prazo} |
| {DD/MM/AAAA} | {ato processual} | {parte/juízo} | {prazo gerado, se houver} |
| {DD/MM/AAAA} | {ato processual} | {parte/juízo} | {prazo gerado, se houver} |

---

## 5. Prazos em Curso

**Base normativa:** CPC/2015, art. 219 (dias úteis), salvo exceção indicada.
**Referência de hoje:** {data da análise}

| # | Prazo | Evento-Gatilho | Data Intimação | Início Contagem | Data-Limite | Dias Restantes | Base Legal | Status |
|---|-------|---------------|---------------|----------------|-------------|---------------|-----------|--------|
| 1 | {ato} | {ato que gerou} | {data} | {data D+1} | {data-limite} | {N dias úteis} | {artigo} | 🔴/🟡/🟠/🟢 |
| 2 | | | | | | | | |

**Legenda:**
- 🔴 CRÍTICO — menos de 3 dias úteis
- 🟡 URGENTE — 3 a 5 dias úteis
- 🟠 ATENÇÃO — 6 a 10 dias úteis
- 🟢 OK — mais de 10 dias úteis
- ✅ CUMPRIDO — ato já praticado
- ⬛ VENCIDO — prazo expirado sem ato registrado

---

## 6. Riscos Processuais

### 🔴 CRÍTICO
{listar risco | ou: "Nenhum risco crítico identificado"}

### 🟡 ATENÇÃO
{listar risco | ou: "Nenhum ponto de atenção identificado"}

### 🟢 OBSERVAÇÃO
{listar observação | ou: "Sem observações adicionais"}

### ✅ Verificações OK
- {item verificado e aprovado}
- {item verificado e aprovado}

---

*Análise factual com base nos documentos fornecidos. Não constitui parecer jurídico.*
*Confirmar todos os dados no sistema judicial (PJe/e-SAJ) antes de qualquer ato processual.*
*Analista Processual Squad v1.1.0 — {data}*
```
