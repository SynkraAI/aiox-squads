# Template — Mapeamento de Riscos Processuais

> Analista Processual Squad v1.1.0 | Executor: mapeador-riscos

---

```markdown
# Mapeamento de Riscos Processuais

**Processo:** {número CNJ}
**Tribunal/Vara:** {identificação}
**Demanda:** {nome da demanda ativa}
**Data da análise:** {DD/MM/AAAA}

---

## 🔴 RISCOS CRÍTICOS
{Prescrição, decadência, nulidade absoluta, incompetência absoluta, coisa julgada, litispendência}

| # | Risco | Descrição | Recomendação Imediata |
|---|-------|-----------|----------------------|
| 1 | {tipo de risco} | {descrição detalhada} | {ação recomendada} |

{ou: "Nenhum risco crítico identificado com base nos documentos fornecidos."}

---

## 🟡 PONTOS DE ATENÇÃO
{Irregularidades sanáveis, incompetência relativa, documentação incompleta, nulidades relativas}

| # | Risco | Descrição | Prazo para Agir |
|---|-------|-----------|----------------|
| 1 | {tipo} | {descrição} | {prazo ou "Sem prazo específico"} |

{ou: "Nenhum ponto de atenção identificado."}

---

## 🟢 OBSERVAÇÕES
{Pontos de atenção que não comprometem imediatamente o processo}

| # | Item | Descrição |
|---|------|-----------|
| 1 | {item} | {descrição} |

{ou: "Sem observações adicionais."}

---

## ✅ VERIFICAÇÕES OK

### Nível 1 — Existência do Processo
- [x] Petição inicial válida presente
- [x] Citação do réu realizada
- [x] Órgão julgador com jurisdição

### Nível 2 — Validade dos Pressupostos
- [x] Competência absoluta verificada
- [x] Capacidade processual das partes
- [x] Representação por advogado regular

### Nível 3 — Condições da Ação
- [x] Legitimidade ativa verificada
- [x] Legitimidade passiva verificada
- [x] Interesse processual presente

### Nível 4 — Objeções Substanciais
- [x] Prescrição: {status — "Não identificada" ou "Prazo: X, último ato interruptivo: data"}
- [x] Decadência: {status}
- [x] Coisa julgada: não identificada
- [x] Litispendência: não identificada

### Nível 5 — Regularidade Formal
- [x] Documentos essenciais juntados (art. 320, CPC/2015)
- [x] Custas recolhidas

---

*Análise com base nos documentos fornecidos.*
*Riscos adicionais podem existir em documentos não fornecidos para análise.*
*Não constitui parecer jurídico.*
*Analista Processual Squad v1.1.0 — {data}*
```
