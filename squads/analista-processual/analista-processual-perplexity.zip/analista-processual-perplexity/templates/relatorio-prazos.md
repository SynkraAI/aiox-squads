# Template — Mapeamento de Prazos Processuais

> Analista Processual Squad v1.1.0 | Executor: calculador-prazos

---

```markdown
# Mapeamento de Prazos Processuais

**Processo:** {número CNJ}
**Tribunal/Vara:** {identificação}
**Demanda:** {nome da demanda ativa}
**Mapeamento gerado em:** {DD/MM/AAAA}
**Base normativa:** CPC/2015, arts. 212-232 (dias úteis, salvo exceção indicada)

---

## ⚠️ Alertas de Urgência

{Mostrar esta seção APENAS se houver prazos VENCIDOS ou CRÍTICOS}

🔴 CRÍTICO: {nome do prazo} vence em {data} ({N} dias úteis restantes)
⬛ VENCIDO: {nome do prazo} venceu em {data} — verificar imediatamente

---

## Tabela de Prazos

| # | Prazo | Ato-Gatilho | Data Intimação | Início Contagem | Data-Limite | Dias Restantes | Base Legal | Status |
|---|-------|------------|---------------|----------------|-------------|---------------|-----------|--------|
| 1 | Contestação | Citação | {data} | {data D+1} | {data} | {N} dias úteis | Art. 335, CPC | 🔴/🟡/🟠/🟢 |
| 2 | Impugnação ao valor | Citação | {data} | {data D+1} | {data} | {N} dias úteis | Art. 293, CPC | |
| 3 | {prazo} | {gatilho} | {data} | {data} | {data} | | {base} | |

**Legenda:**
- 🔴 CRÍTICO — menos de 3 dias úteis
- 🟡 URGENTE — 3 a 5 dias úteis
- 🟠 ATENÇÃO — 6 a 10 dias úteis
- 🟢 OK — mais de 10 dias úteis
- ✅ CUMPRIDO — ato já praticado
- ⬛ VENCIDO — prazo expirado sem ato registrado

---

## Suspensões em Vigor

{Informar se há suspensão de prazos em vigor}
{Ex: "Não há suspensão de prazos em vigor." ou "Férias forenses: 1-31/07/2026"}

---

## Feriados Considerados

{Listar feriados nacionais considerados no período de contagem}
{Nota: feriados locais (municipais/estaduais) devem ser informados pelo usuário}

---

*Datas calculadas com base nas informações fornecidas.*
*Confirmar no sistema judicial (PJe/e-SAJ) antes de qualquer ato.*
*Feriados locais (municipais e estaduais) não incluídos — informar ao analista para recálculo.*
```
