# Template — Resumo Executivo

> Analista Processual Squad v1.1.0 | Executor: analista-processual

---

```markdown
# Resumo Executivo — Processo {número}

**Data:** {DD/MM/AAAA} | **Analista:** Analista Processual v1.1.0
**Demanda:** {nome da demanda ativa}

---

## Em Uma Linha
{Ação de [tipo] movida por [autor] contra [réu] por [motivo central].}

---

## Situação Atual

- **Fase:** {fase processual atual}
- **Tribunal/Vara:** {identificação completa}
- **Último ato:** {DD/MM/AAAA} — {descrição do último ato}
- **Próximo passo esperado:** {o que deve acontecer a seguir}

---

## Partes

- **Autor(a):** {nome} — Adv. {nome do advogado}
- **Réu/Ré:** {nome} — Adv. {nome do advogado}
- **Terceiros:** {nome ou "Não há terceiros"}

---

## O que está em discussão

{2-4 linhas descrevendo o objeto e os pedidos principais.}
{Linguagem clara, sem excesso de juridiquês.}

**Valor estimado em disputa:** R$ {valor}

---

## Prazos Imediatos

| Prazo | Vencimento | Dias Restantes | Urgência |
|-------|-----------|---------------|---------|
| {ato} | {data} | {N dias úteis} | 🔴/🟡/🟠/🟢 |
| {ato} | {data} | {N dias úteis} | |

---

## Pontos de Atenção

{Máximo 3 itens — apenas os mais críticos}

- 🔴 {risco crítico, se houver}
- 🟡 {ponto de atenção, se houver}
- 🟢 {observação relevante, se houver}

---

*Resumo para acompanhamento interno. Não substitui análise completa nem parecer jurídico.*
*Analista Processual Squad v1.1.0 — {data}*
```
