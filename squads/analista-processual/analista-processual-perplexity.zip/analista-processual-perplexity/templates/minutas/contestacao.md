# Template — Minuta de Contestação

> Analista Processual Squad v1.1.0
> ⚠️ RASCUNHO — Deve ser revisado, adaptado e assinado pelo advogado responsável

---

```markdown
[LOCAL], {DD} de {mês} de {AAAA}.

EXMO(A). SR(A). JUIZ(A) DE DIREITO DA {N}ª VARA CÍVEL DA COMARCA DE {CIDADE/UF}

Processo n.º {NNNNNNN-DD.AAAA.J.TT.OOOO}

{NOME DO RÉU}, {qualificação completa: nacionalidade, estado civil, profissão, CPF/CNPJ, RG, endereço}, por intermédio de seu advogado infra-assinado (procuração em anexo), vem, respeitosamente, à presença de Vossa Excelência, nos autos da {tipo de ação} que lhe move {NOME DO AUTOR}, apresentar

CONTESTAÇÃO

pelos fatos e fundamentos a seguir expostos:

---

⚠️ REVISAR: Verificar se há preliminares a arguir. Se não houver, remover o item II inteiro.

## I — QUALIFICAÇÃO DO RÉU

{NOME DO RÉU}, {qualificação completa}, devidamente representado pelo(a) advogado(a) infra-assinado(a), conforme procuração em anexo.

---

## II — PRELIMINARES

⚠️ REVISAR: Incluir apenas as preliminares aplicáveis ao caso.

### 2.1 — {Tipo de Preliminar, ex: Incompetência Absoluta}
{Desenvolver o argumento da preliminar com base legal}
**Fundamento:** {artigo de lei}

### 2.2 — {Outra preliminar, se houver}
{Desenvolver}

---

## III — NO MÉRITO

### 3.1 — Da Impugnação dos Fatos

⚠️ REVISAR: Impugnar especificamente cada fato alegado pelo autor. Impugnação genérica é ineficaz (art. 341, CPC/2015).

📋 COMPLETAR: Identificar e impugnar os fatos controvertidos com base nos documentos do processo.

{Impugnar os fatos:}
{Quanto ao fato [X] alegado na inicial, o Réu esclarece que...}
{Quanto ao fato [Y]...}

### 3.2 — Dos Fundamentos Jurídicos

📋 COMPLETAR: Inserir os argumentos jurídicos de defesa.

{Desenvolver os argumentos jurídicos do réu com citação de artigos de lei}

**Base legal:** {artigos invocados}

### 3.3 — Da Jurisprudência Favorável

📋 COMPLETAR: Pesquisar e inserir precedentes aplicáveis (use *pesquisar-jurisprudencia).

{Citar jurisprudência relevante do STJ, STF ou tribunal local}

---

## IV — DA RECONVENÇÃO (se aplicável)

⚠️ REVISAR: Incluir apenas se houver reconvenção. Caso contrário, remover este item.
⚖️ ESTRATÉGIA: Avaliar com o advogado a conveniência de reconvir.

{Fundamento da reconvenção}
**Base legal:** Art. 343, CPC/2015

---

## V — DOS PEDIDOS

Ante o exposto, requer a Vossa Excelência:

{Selecionar os pedidos aplicáveis:}

a) O acolhimento das preliminares arguídas, com a extinção do processo sem resolução do mérito (art. 485, CPC/2015);

b) Na hipótese de superadas as preliminares, a total improcedência dos pedidos formulados na petição inicial;

c) A condenação do Autor ao pagamento das custas processuais e honorários advocatícios de sucumbência, nos termos do art. 85, CPC/2015;

d) 📋 COMPLETAR: Outros pedidos específicos do caso.

---

## VI — DOS REQUERIMENTOS

Requer, ainda:

a) A produção de todos os meios de prova em direito admitidos, especialmente:
   - Prova documental (documentos em anexo)
   - 📋 COMPLETAR: Prova testemunhal (rol de testemunhas a apresentar no momento oportuno)
   - 📋 COMPLETAR: Prova pericial (se aplicável)

b) A intimação do Autor para se manifestar sobre os documentos ora juntados.

---

Nestes termos,
Pede deferimento.

{CIDADE}, {data}

_______________________________________
{NOME DO ADVOGADO}
OAB/{UF} {NÚMERO}
{ESCRITÓRIO}
{ENDEREÇO}
{TELEFONE/E-MAIL}

---

📄 DOCUMENTO: Lista de anexos
- Procuração
- {documentos específicos do caso}

---

⚠️ Esta minuta é um rascunho para uso interno.
Deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.
Analista Processual Squad v1.1.0
```
