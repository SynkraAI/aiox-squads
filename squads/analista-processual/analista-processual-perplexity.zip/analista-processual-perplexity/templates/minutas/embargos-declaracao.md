# Template — Minuta de Embargos de Declaração

> Analista Processual Squad v1.1.0
> Base legal: Arts. 1.022-1.026, CPC/2015
> Prazo: 5 dias úteis (art. 1.023)
> ⚠️ RASCUNHO — Deve ser revisado, adaptado e assinado pelo advogado responsável

---

```markdown
EXMO(A). SR(A). JUIZ(A) DE DIREITO DA {N}ª VARA CÍVEL DE {COMARCA}
(ou: EXMO(A). SR(A). DESEMBARGADOR(A) RELATOR(A) DO {TRIBUNAL})

Processo n.º {número CNJ}
Embargante: {nome da parte}
Embargado: {nome da parte contrária}

{NOME DA PARTE}, já qualificada nos autos, por intermédio de seu advogado infra-assinado, vem, nos termos dos arts. 1.022-1.026 do Código de Processo Civil, opor

EMBARGOS DE DECLARAÇÃO

contra a {sentença/decisão/acórdão} proferida em {data}, pelos fundamentos a seguir.

---

## I — DA TEMPESTIVIDADE

⚠️ REVISAR: Confirmar a data de publicação e o prazo de 5 dias úteis.

A {sentença/decisão/acórdão} foi publicada em {data de publicação}, iniciando-se a contagem do prazo em {data D+1 útil}. O prazo de 5 dias úteis vence em {data-limite}. Os presentes embargos são, portanto, tempestivos (art. 1.023, CPC/2015).

---

## II — DO VÍCIO APONTADO

⚠️ REVISAR: Selecionar e desenvolver apenas o(s) vício(s) efetivamente presente(s). Remover os demais.

### Opção A — OMISSÃO (art. 1.022, II, CPC/2015)

A decisão embargada silenciou sobre {descrever o pedido ou questão omitida}.

Com efeito, na petição {inicial/recursal/de fls. XX}, a parte Embargante postulou expressamente {descrever o pedido omitido}. Entretanto, o {sentenciante/julgador} não apreciou tal ponto, incidindo em omissão que deve ser suprida.

**Fundamento:** Art. 1.022, II, CPC/2015

---

### Opção B — CONTRADIÇÃO (art. 1.022, I, CPC/2015)

A decisão embargada contém contradição insanável, pois afirma {X} no {parágrafo/fls. XX}, mas conclui {Y} no {parágrafo/fls. XX}.

📋 COMPLETAR: Indicar os trechos contraditórios com citação literal.

{Citar o trecho A da decisão}
{Citar o trecho B que contradiz o trecho A}

**Fundamento:** Art. 1.022, I, CPC/2015

---

### Opção C — OBSCURIDADE (art. 1.022, I, CPC/2015)

A decisão embargada é obscura quanto a {ponto específico}, pois não está claro se {descrever a ambiguidade}.

**Fundamento:** Art. 1.022, I, CPC/2015

---

### Opção D — ERRO MATERIAL (art. 1.022, parágrafo único, CPC/2015)

A decisão embargada contém erro material: indica {X}, quando o correto seria {Y}, conforme consta de {documento/fls.}.

**Fundamento:** Art. 1.022, parágrafo único, CPC/2015

---

## III — DO PEDIDO

Ante o exposto, requer a Vossa Excelência:

a) O CONHECIMENTO dos presentes embargos, por tempestivos e fundados em vício previsto no art. 1.022 do CPC/2015;

b) O ACOLHIMENTO dos embargos, para {sanar a omissão / eliminar a contradição / esclarecer a obscuridade / corrigir o erro material}, {descrevendo o resultado pretendido};

⚖️ ESTRATÉGIA: Se os embargos visam efeito infringente (modificar o resultado), incluir o pedido abaixo:

c) {FACULTATIVO} O reconhecimento do EFEITO INFRINGENTE dos presentes embargos, sanando o vício apontado e reformando a decisão para {descrever o resultado pretendido}.

---

Nestes termos,
Pede deferimento.

{CIDADE}, {data}

_______________________________________
{NOME DO ADVOGADO}
OAB/{UF} {NÚMERO}

---

⚠️ Esta minuta é um rascunho para uso interno.
Deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.
Analista Processual Squad v1.1.0
```
