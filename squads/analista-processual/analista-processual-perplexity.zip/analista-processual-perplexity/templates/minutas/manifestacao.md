# Template — Minuta de Manifestação / Petição Simples

> Analista Processual Squad v1.1.0
> Uso: Resposta a intimações, juntada de documentos, requerimentos simples
> ⚠️ RASCUNHO — Deve ser revisado, adaptado e assinado pelo advogado responsável

---

```markdown
EXMO(A). SR(A). JUIZ(A) DE DIREITO DA {N}ª VARA {CÍVEL/TRABALHISTA/FEDERAL} DE {COMARCA}

Processo n.º {número CNJ}

{NOME DA PARTE}, {qualificação}, por intermédio de seu advogado infra-assinado, nos autos do processo em epígrafe, vem, respeitosamente, perante Vossa Excelência, {OBJETO DA PETIÇÃO}:

---

⚖️ ESTRATÉGIA: Selecionar o modelo adequado ao tipo de manifestação. Remover os demais.

---

## MODELO A — Resposta a Intimação

{NOME DA PARTE}, intimada em {data} para {objeto da intimação}, vem manifestar-se nos seguintes termos:

📋 COMPLETAR: Desenvolver a manifestação conforme o objeto da intimação.

{Conteúdo da resposta à intimação}

Diante do exposto, requer que Vossa Excelência {pedido decorrente da manifestação}.

---

## MODELO B — Juntada de Documentos

{NOME DA PARTE} vem juntar aos autos os documentos a seguir elencados:

📄 DOCUMENTO: {documento 1 — descrever brevemente}
📄 DOCUMENTO: {documento 2 — descrever brevemente}
📄 DOCUMENTO: {documento 3 — descrever brevemente}

Os documentos ora juntados {demonstram/comprovam/corroboram} {descrever a relevância para o processo}.

Requer seja determinada a intimação da parte contrária para manifestação, nos termos do art. 437, §1º, CPC/2015.

---

## MODELO C — Requerimento de Prazo

{NOME DA PARTE}, ciente da intimação de fls. {fls.}, vem, com fundamento no art. 218, §3º, CPC/2015, requerer a concessão de prazo de 15 (quinze) dias úteis para {objeto do requerimento}, tendo em vista {justificativa}.

---

## MODELO D — Impugnação a Laudo Pericial

{NOME DA PARTE}, tendo sido intimada do laudo pericial juntado em {data}, vem impugná-lo pelos seguintes fundamentos:

📋 COMPLETAR: Inserir os pontos específicos de impugnação com base técnica.

1. {Ponto de impugnação 1}: {argumentação}
2. {Ponto de impugnação 2}: {argumentação}

Requer a intimação do(a) perito(a) para esclarecimentos, nos termos do art. 477, §1º, CPC/2015.

---

## MODELO E — Indicação de Endereço para Citação/Intimação

{NOME DA PARTE} vem informar o endereço atualizado {da parte/do réu} para fins de {citação/intimação}:

{Endereço completo: logradouro, número, complemento, bairro, cidade, estado, CEP}
{Telefone de contato: (XX) XXXXX-XXXX}
{E-mail (se houver): xxxxx@xxxxx.com}

---

## FECHAMENTO PADRÃO

Diante do exposto, requer o recebimento e o processamento desta petição.

Nestes termos,
Pede deferimento.

{CIDADE}, {data}

_______________________________________
{NOME DO ADVOGADO}
OAB/{UF} {NÚMERO}
{ESCRITÓRIO}
{TELEFONE/E-MAIL}

---

⚠️ Esta minuta é um rascunho para uso interno.
Deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.
Analista Processual Squad v1.1.0
```
