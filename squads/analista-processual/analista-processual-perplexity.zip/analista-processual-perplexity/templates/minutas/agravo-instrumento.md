# Template — Minuta de Agravo de Instrumento

> Analista Processual Squad v1.1.0
> Base legal: Arts. 1.015-1.020, CPC/2015
> Prazo: 15 dias úteis (art. 1.003, §5º)
> ⚠️ RASCUNHO — Deve ser revisado, adaptado e assinado pelo advogado responsável

---

```markdown
EXMO(A). SR(A). DESEMBARGADOR(A) RELATOR(A) DO {TRIBUNAL DE DESTINO}

Processo n.º {número CNJ — do processo de origem}

{NOME DA PARTE}, já qualificada nos autos, por intermédio de seu advogado infra-assinado, não se conformando com a decisão interlocutória proferida em {data}, vem, tempestivamente, interpor

AGRAVO DE INSTRUMENTO

(Arts. 1.015-1.020, CPC/2015)

pelos fundamentos a seguir.

---

## I — DO CABIMENTO

⚠️ REVISAR: Verificar se a decisão se enquadra no rol TAXATIVO do art. 1.015, CPC/2015. Decisões não listadas não são agraváveis de imediato.

A decisão agravada é agravável porque {indicar o inciso do art. 1.015}:

**Fundamento de cabimento:** Art. 1.015, {inciso}, CPC/2015

Rol de decisões agraváveis (art. 1.015, CPC/2015):
- I — tutelas provisórias
- II — mérito do processo
- III — rejeição da alegação de convenção de arbitragem
- IV — incidente de desconsideração da personalidade jurídica
- V — rejeição do pedido de gratuidade da justiça ou acolhimento do pedido de sua revogação
- VI — exclusão de litisconsorte
- VII — rejeição do pedido de limitação do litisconsórcio
- VIII — admissão ou inadmissão de intervenção de terceiros
- IX — competência
- X — concessão, modificação ou revogação do efeito suspensivo aos embargos à execução
- XI — redistribuição do ônus da prova nos termos do art. 373, §1º
- XIII — outros casos expressamente referidos em lei

---

## II — DA TEMPESTIVIDADE

⚠️ REVISAR: Confirmar a data de intimação da decisão e calcular o prazo de 15 dias úteis.

A decisão foi proferida em {data} e intimada em {data de intimação}, iniciando-se a contagem em {data D+1 útil}. O prazo de 15 dias úteis vence em {data-limite}. O presente recurso é, portanto, tempestivo (art. 1.003, §5º, CPC/2015).

---

## III — DA DECISÃO AGRAVADA

A decisão agravada {descreveu/determinou/indeferiu} {resumo da decisão em 2-5 linhas}.

📋 COMPLETAR: Transcrever ou resumir o teor da decisão agravada.

{Transcrição ou resumo da decisão}

---

## IV — DA URGÊNCIA E DO EFEITO SUSPENSIVO (se aplicável)

⚖️ ESTRATÉGIA: Incluir este item apenas se for necessário requerer efeito suspensivo ou antecipação da tutela recursal.

A concessão do efeito suspensivo se impõe porque estão presentes os requisitos do art. 995, parágrafo único, CPC/2015:

a) **Probabilidade de provimento do recurso:** {fundamentar}
b) **Risco de dano grave ou difícil reparação:** {demonstrar a urgência}

---

## V — DAS RAZÕES DE REFORMA

### 5.1 — {Primeiro fundamento para reforma}

{Argumentar por que a decisão está errada, com base legal}

**Fundamento:** {artigo(s) de lei}

### 5.2 — {Segundo fundamento, se houver}

📋 COMPLETAR: Desenvolver os demais argumentos.

---

## VI — DO PEDIDO

Ante o exposto, requer a Vossa Excelência:

a) O CONHECIMENTO do presente recurso, por ser tempestivo e cabível;

{b) Se houver pedido de efeito suspensivo:}
b) A concessão IMEDIATA do efeito suspensivo (ou tutela antecipada recursal), nos termos do art. 1.019, I, c/c art. 995, parágrafo único, CPC/2015;

c) O PROVIMENTO do recurso, para reformar a decisão agravada, {descrevendo o resultado pretendido};

d) A intimação do Agravado para contraminuta (art. 1.019, II, CPC/2015).

---

Nestes termos,
Pede deferimento.

{CIDADE}, {data}

_______________________________________
{NOME DO ADVOGADO}
OAB/{UF} {NÚMERO}

---

📄 DOCUMENTO: Cópia da decisão agravada
📄 DOCUMENTO: Cópia da petição que originou a decisão
📄 DOCUMENTO: Procuração
📄 DOCUMENTO: Certidão de intimação da decisão
📄 DOCUMENTO: 📋 COMPLETAR — Outros documentos necessários para instrução do agravo

---

⚠️ Esta minuta é um rascunho para uso interno.
Deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.
Analista Processual Squad v1.1.0
```
