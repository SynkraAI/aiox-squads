# Template — Minuta de Apelação

> Analista Processual Squad v1.1.0
> Base legal: Arts. 1.009-1.014, CPC/2015
> ⚠️ RASCUNHO — Deve ser revisado, adaptado e assinado pelo advogado responsável

---

```markdown
EXMO(A). SR(A). DESEMBARGADOR(A) RELATOR(A) DO {TRIBUNAL DE DESTINO}

Processo n.º {número CNJ}
Apelante: {nome da parte que recorre}
Apelado: {nome da parte contrária}

{NOME DA PARTE}, já qualificada nos autos, por intermédio de seu advogado infra-assinado, não se conformando com a r. sentença proferida em {data}, vem, tempestivamente, interpor

RECURSO DE APELAÇÃO

(Arts. 1.009-1.014, CPC/2015)

pelos fundamentos a seguir expostos.

---

## I — DA TEMPESTIVIDADE

⚠️ REVISAR: Confirmar a data de publicação da sentença e calcular o prazo de 15 dias úteis.

A sentença foi publicada em {data de publicação}, iniciando-se a contagem do prazo recursal em {data D+1 útil}. O prazo de 15 dias úteis vence em {data-limite}. O presente recurso é, portanto, tempestivo (art. 1.003, §5º, CPC/2015).

---

## II — DO CABIMENTO E DA LEGITIMIDADE

A apelação é o recurso cabível para impugnar sentença que resolve o mérito (art. 1.009, CPC/2015). A parte Apelante é legítima para recorrer, pois foi {sucumbente total/parcialmente sucumbente} no feito (art. 996, CPC/2015).

---

## III — DO PREPARO

📋 COMPLETAR: Verificar o valor do preparo junto à tabela de custas do {tribunal}.

O preparo foi recolhido conforme comprovante em anexo (Guia de Recolhimento n.º {número}), no valor de R$ {valor}, correspondente a {X}% sobre o valor da condenação/causa.

⚠️ REVISAR: Confirmar a base de cálculo e o percentual de preparo junto ao regimento de custas do tribunal.

---

## IV — DOS FATOS E DA DECISÃO RECORRIDA

A sentença proferida em {data} julgou {procedente/improcedente/parcialmente procedente} o pedido formulado por {autor}, {descrevendo sucintamente o resultado}.

📋 COMPLETAR: Descrever brevemente os fatos do processo e o teor da sentença recorrida.

{Resumo dos fatos e da sentença — 5-10 linhas}

---

## V — DAS RAZÕES DE REFORMA

### 5.1 — {Primeiro Fundamento para Reforma}

⚠️ REVISAR: Desenvolver o argumento de reforma com base nos fatos e no direito.

{Argumentar que a sentença errou ao...}

**Fundamento legal:** {artigo(s) de lei}

### 5.2 — {Segundo Fundamento}

📋 COMPLETAR: Inserir demais fundamentos.

{Desenvolver}

### 5.3 — Da Violação ao Princípio/Norma {X}

⚖️ ESTRATÉGIA: Avaliar se cabe alegação de violação a normas processuais ou materiais específicas.

{Desenvolver, se aplicável}

---

## VI — DA JURISPRUDÊNCIA FAVORÁVEL

📋 COMPLETAR: Pesquisar precedentes do STJ, STF ou tribunal local favoráveis à tese (use *pesquisar-jurisprudencia).

{Citar e transcrever ementas relevantes}

---

## VII — DO PEDIDO

Ante o exposto, requer a Vossa Excelência:

a) O CONHECIMENTO do presente recurso, por ser tempestivo e preencher todos os requisitos de admissibilidade;

b) O PROVIMENTO do recurso, para reformar a sentença recorrida {no ponto X / integralmente}, {descrevendo o resultado pretendido};

c) A condenação do Apelado ao pagamento das custas recursais e honorários advocatícios recursais, nos termos do art. 85, §11, CPC/2015.

📋 COMPLETAR: Inserir pedido específico de acordo com o resultado pretendido.

---

Nestes termos,
Pede deferimento.

{CIDADE}, {data}

_______________________________________
{NOME DO ADVOGADO}
OAB/{UF} {NÚMERO}

---

📄 DOCUMENTO: Guia de preparo recursal
📄 DOCUMENTO: Certidão de intimação da sentença

---

⚠️ Esta minuta é um rascunho para uso interno.
Deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer protocolo.
Analista Processual Squad v1.1.0
```
