# Template — Análise de Sentença

> Analista Processual Squad v1.1.0 | Executor: analista-processual

---

```markdown
# Análise de Sentença

**Processo:** {número CNJ}
**Juiz(a):** {nome ou "Não identificado"}
**Data da sentença:** {DD/MM/AAAA}
**Data de publicação/intimação:** {DD/MM/AAAA}
**Demanda:** {nome da demanda ativa}

---

## Resultado Geral

**Dispositivo:** {Procedente | Procedente em parte | Improcedente | Extinção sem resolução do mérito}
**Resultado para o Autor:** {favorável | parcialmente favorável | desfavorável}
**Resultado para o Réu:** {favorável | parcialmente favorável | desfavorável}

---

## Análise por Pedido

| # | Pedido | Resultado | Observação |
|---|--------|-----------|-----------|
| 1 | {pedido principal} | Procedente/Improcedente/Parcial | |
| 2 | {pedido subsidiário} | | |
| 3 | {pedido de antecipação de tutela} | | |

---

## Condenações (Dispositivo)

| Item | Valor/Condição | Índice | Base Legal |
|------|---------------|--------|-----------|
| Condenação principal | R$ {valor} ou {obrigação} | — | |
| Juros de mora | {taxa}% a.m. | desde {data} | |
| Correção monetária | {índice} | desde {data} | |
| Honorários advocatícios | {%} sobre {base} | — | Art. 85, CPC |
| Custas processuais | {parte sucumbente} | — | Art. 86/87, CPC |

---

## Fundamentos da Decisão

### Questões Preliminares Decididas
{listar ou "Nenhuma questão preliminar decidida"}

### Fundamentos de Mérito
{Resumo dos fundamentos jurídicos centrais — 3-5 pontos principais}

1. {fundamento principal}
2. {fundamento}
3. {fundamento}

---

## Prazos Recursais

| Recurso | Prazo | Data Publicação | Início Contagem | Vencimento | Legitimado |
|---------|-------|----------------|----------------|-----------|-----------|
| Embargos de Declaração | 5 dias úteis | {data} | {data D+1} | {data} | Qualquer parte |
| Apelação | 15 dias úteis | {data} | {data D+1} | {data} | Parte sucumbente |

**Base legal:** Art. 1.023 (embargos) e Art. 1.003, §5º (apelação), CPC/2015

---

## Pontos para Análise Recursal

### Possíveis Embargos de Declaração (art. 1.022, CPC)
{listar omissão, contradição, obscuridade ou erro material — ou "Nenhum vício identificado"}

### Pontos para Apelação
{listar aspectos favoráveis à revisão em 2º grau — ou "A critério do advogado responsável"}

---

## Documentos Necessários para Recurso

- [ ] Certidão de intimação (confirmar data de publicação)
- [ ] Cópia da sentença autenticada
- [ ] Procuração com poderes para recorrer (verificar se já consta nos autos)
- [ ] Preparo recursal (valor conforme tabela do {tribunal})
- [ ] {outros documentos específicos}

---

*Análise factual da sentença. Não constitui orientação sobre estratégia recursal.*
*Responsabilidade do advogado subscritor a decisão de recorrer e a elaboração da peça recursal.*
*Analista Processual Squad v1.1.0 — {data}*
```
