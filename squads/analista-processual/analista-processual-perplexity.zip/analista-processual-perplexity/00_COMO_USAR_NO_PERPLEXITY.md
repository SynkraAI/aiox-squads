# ⚖️ Analista Processual Squad — Guia de Uso no Perplexity

> Squad AIOX v1.1.0 | Domínio: Direito Processual Civil Brasileiro | Score: 9.2/10 🟢

---

## O que está neste pacote

Este .zip contém o squad **Analista Processual** adaptado para uso no **Perplexity AI** através da funcionalidade **computer/Habilidades**. O squad é um sistema completo de análise de processos judiciais brasileiros com base no CPC/2015.

```
analista-processual-perplexity/
├── 00_COMO_USAR_NO_PERPLEXITY.md      ← Este arquivo (leia primeiro)
├── 01_HABILIDADE_PRINCIPAL.md          ← Cole no campo "Habilidade" do Perplexity
├── agentes/
│   ├── calculador-prazos.md            ← Agente especialista em prazos
│   ├── extrator-documentos.md          ← Agente de extração de peças
│   ├── mapeador-riscos.md              ← Agente de riscos processuais
│   ├── gestor-biblioteca.md            ← Agente da biblioteca de conhecimento
│   └── navegador-arquivos.md           ← Agente de gestão de pastas
├── tarefas/
│   ├── analisar-processo.md            ← Fluxo de análise completa
│   ├── mapear-prazos.md                ← Fluxo de mapeamento de prazos
│   ├── resumir-processo.md             ← Fluxo de resumo executivo
│   ├── analisar-sentenca.md            ← Fluxo de análise de sentença
│   ├── elaborar-minuta.md              ← Fluxo de elaboração de minutas
│   └── selecionar-demanda.md           ← Fluxo de seleção de demanda
├── referencia/
│   ├── prazos-cpc2015.md               ← Tabela completa de prazos
│   ├── checklist-analise.md            ← Checklist de qualidade
│   └── estrutura-pastas.md             ← Mapa do sistema de arquivos
└── templates/
    ├── relatorio-analise-processual.md ← Template de relatório
    ├── relatorio-prazos.md             ← Template de mapeamento de prazos
    ├── relatorio-riscos.md             ← Template de riscos
    ├── resumo-executivo.md             ← Template de resumo
    ├── analise-sentenca.md             ← Template de análise de sentença
    └── minutas/
        ├── contestacao.md
        ├── apelacao.md
        ├── embargos-declaracao.md
        ├── agravo-instrumento.md
        └── manifestacao.md
```

---

## Método 1 — Usar como Habilidade no Perplexity (Recomendado)

### Passo a Passo

**1. Acesse as configurações de Habilidades**
- No Perplexity, acesse: `Configurações → Habilidades (Skills)` ou a seção `computer/Habilidades`
- Clique em **"+ Nova Habilidade"**

**2. Configure a Habilidade**
- **Nome:** `Analista Processual`
- **Ícone:** ⚖️
- **Descrição:** `Análise de processos judiciais brasileiros com base no CPC/2015`
- **Prompt do sistema (System Prompt):** Cole o conteúdo completo do arquivo `01_HABILIDADE_PRINCIPAL.md`

**3. Salve e ative**

**4. Uso**
```
Ative a habilidade "Analista Processual" e use os comandos:

*analisar-processo    → Análise completa
*mapear-prazos        → Tabela de prazos
*resumir-processo     → Resumo executivo
*analisar-sentenca    → Análise de sentença
*contestacao          → Minuta de contestação
*recurso apelacao     → Minuta de recurso
*riscos               → Mapeamento de riscos
```

---

## Método 2 — Upload de Arquivos como Contexto

Se o Perplexity não suportar Habilidades customizadas na sua conta:

1. **Abra uma nova conversa** no Perplexity
2. **Faça upload** do arquivo `01_HABILIDADE_PRINCIPAL.md`
3. **Diga ao Perplexity:**
   > "Você agora é o Analista Processual conforme as instruções neste arquivo. Siga as instruções de ativação."
4. Para análises específicas, **anexe também** o arquivo de tarefa correspondente:
   - Para análise de processo → `tarefas/analisar-processo.md`
   - Para prazos → `tarefas/mapear-prazos.md`
   - Para minutas → `tarefas/elaborar-minuta.md`

---

## Método 3 — Space/Collection no Perplexity

Se você usar Perplexity Pro com Spaces:

1. **Crie um Space** chamado "Escritório Jurídico" ou "Analista Processual"
2. **Configure o prompt do Space** com o conteúdo de `01_HABILIDADE_PRINCIPAL.md`
3. **Faça upload** de todos os arquivos `.md` deste pacote como documentos do Space
4. O Perplexity usará esses arquivos como base de conhecimento para todas as perguntas do Space

---

## Como Usar na Prática

### Análise de Processo

```
[Ative a Habilidade "Analista Processual"]

*analisar-processo

Número do processo: 1234567-89.2024.8.26.0100

[Cole aqui o texto da petição inicial ou decisão]
```

O squad irá:
1. Identificar tribunal, vara, instância e fase
2. Extrair partes, pedidos e fundamentos
3. Calcular todos os prazos vigentes
4. Mapear riscos processuais
5. Entregar relatório estruturado

---

### Mapeamento de Prazos

```
*mapear-prazos

Processo: 1234567-89.2024.8.26.0100
Último ato: Citação realizada em 10/03/2026
Tribunal: TJSP

[Cole a decisão ou intimação recebida]
```

---

### Análise de Sentença

```
*analisar-sentenca

[Cole o texto completo da sentença]
```

O squad irá:
1. Estruturar relatório, fundamentação e dispositivo
2. Mapear pedidos vs. resultados obtidos
3. Calcular prazo para embargos (5 dias úteis) e apelação (15 dias úteis)
4. Identificar pontos passíveis de recurso

---

### Elaborar Minuta de Contestação

```
*contestacao

[Forneça:
- Texto da petição inicial
- Principais argumentos de defesa
- Documentos disponíveis]
```

---

### Pesquisar na Biblioteca

```
*pesquisar-biblioteca responsabilidade civil nexo causal

[O agente busca no contexto fornecido e nas referências disponíveis]
```

---

## Adaptação para Ambiente sem Google Drive

> O squad foi desenvolvido para rodar com sistema de pastas em `K:\Meu Drive\Processos_Judiciais_IA\`.
> No Perplexity (sem acesso ao sistema de arquivos), use o seguinte fluxo adaptado:

**Em vez de apontar para pastas**, cole diretamente:
- O texto das peças processuais no chat
- Ou faça upload dos PDFs/documentos como anexos

**Para trabalhar com múltiplos documentos**, diga:
```
Demanda ativa: [NOME DA DEMANDA]

Documento 1 — Petição Inicial:
[cola o texto]

Documento 2 — Decisão de 15/03/2026:
[cola o texto]

*analisar-processo
```

---

## Comandos de Referência Rápida

### Navegação e Sessão
| Comando | O que faz |
|---------|-----------|
| `*selecionar-demanda` | Definir qual demanda está sendo trabalhada |
| `*demanda-ativa` | Confirmar demanda da sessão atual |

### Análise Processual
| Comando | O que faz |
|---------|-----------|
| `*analisar-processo` | Análise completa: partes, prazos, cronologia, riscos |
| `*resumir-processo` | Resumo executivo de 1 página |
| `*mapear-prazos` | Tabela de prazos com datas-limite calculadas |
| `*cronologia` | Linha do tempo de todos os atos processuais |
| `*riscos` | Mapeamento de riscos e vícios processuais |
| `*analisar-sentenca` | Análise estruturada de sentença |
| `*analisar-peticao` | Análise de petição inicial ou contestação |

### Minutas
| Comando | O que faz |
|---------|-----------|
| `*contestacao` | Elaborar minuta de contestação |
| `*recurso apelacao` | Elaborar minuta de apelação |
| `*recurso agravo` | Elaborar agravo de instrumento |
| `*recurso embargos` | Elaborar embargos de declaração |
| `*manifestacao` | Elaborar manifestação ou petição simples |
| `*peticao-inicial` | Elaborar minuta de petição inicial |

### Biblioteca
| Comando | O que faz |
|---------|-----------|
| `*pesquisar-biblioteca {tema}` | Buscar doutrina e jurisprudência |
| `*pesquisar-jurisprudencia {tema} {tribunal}` | Buscar precedentes |

---

## Limitações no Perplexity

| Limitação | Workaround |
|-----------|-----------|
| Sem acesso ao Google Drive / K: | Cole o texto das peças diretamente no chat |
| Sem acesso ao PJe/e-SAJ | Forneça os documentos manualmente |
| Sem persistência de sessão | Reinforme a demanda ativa a cada conversa |
| Sem salvamento automático na biblioteca | Copie as minutas e salve manualmente |

---

## Base Normativa do Squad

| Norma | Aplicação |
|-------|-----------|
| **CPC/2015** (Lei 13.105/2015) | Referência primária para prazos e procedimentos |
| **CF/1988** | Garantias processuais fundamentais |
| **CLT** | Processos trabalhistas |
| **CDC** — Lei 8.078/1990 | Processos consumeristas |
| **Lei 6.830/1980** | Execução Fiscal |
| **Lei 9.099/1995** | Juizados Especiais |

---

## Avisos Importantes

> ⚠️ **As minutas são rascunhos.** Toda peça processual elaborada pelo squad deve ser revisada, adaptada e assinada pelo advogado responsável antes de qualquer uso oficial.

> ⚠️ **Não é parecer jurídico.** O squad realiza análise factual e processual com base nos documentos fornecidos. Não substitui a orientação do advogado.

> ⚠️ **Confirme prazos no tribunal.** Todos os prazos calculados devem ser confirmados no sistema judicial (PJe, e-SAJ, PROJUDI) antes de qualquer ato processual.

---

*Squad Analista Processual v1.1.0 — AIOX Squads Community | Licença MIT*
