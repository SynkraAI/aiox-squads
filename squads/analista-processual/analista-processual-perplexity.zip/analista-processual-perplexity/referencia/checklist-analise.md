# Checklist — Análise Processual Completa

> Use antes de entregar qualquer relatório de análise processual.
> Analista Processual Squad v1.1.0

---

## 1. Identificação (obrigatório)
- [ ] Número do processo no formato CNJ (NNNNNNN-DD.AAAA.J.TT.OOOO)
- [ ] Tribunal e vara/câmara identificados
- [ ] Instância identificada (1º grau | 2º grau | STJ | STF)
- [ ] Classe processual identificada (Procedimento Comum | Sumário | JEC | Trabalhista | etc.)
- [ ] Fase processual atual identificada (distribuição | instrução | sentença | recurso | execução)

## 2. Partes
- [ ] Polo ativo identificado (nome + CPF/CNPJ)
- [ ] Polo passivo identificado (nome + CPF/CNPJ)
- [ ] Advogado(s) do polo ativo identificado(s) (nome + OAB)
- [ ] Advogado(s) do polo passivo identificado(s) (nome + OAB)
- [ ] Terceiros interessados identificados (se houver)

## 3. Objeto da Ação
- [ ] Tipo de ação identificado
- [ ] Pedido principal extraído
- [ ] Pedidos subsidiários/cumulados listados
- [ ] Fundamentos jurídicos invocados listados (artigos de lei)
- [ ] Valor da causa identificado

## 4. Cronologia
- [ ] Data de distribuição identificada
- [ ] Atos processuais principais listados em ordem cronológica
- [ ] Último ato processual identificado com data precisa

## 5. Prazos
- [ ] Todos os prazos correntes calculados
- [ ] Data-início de cada prazo identificada (D+1 útil após intimação)
- [ ] Data-limite de cada prazo calculada (dias úteis, CPC/2015)
- [ ] Forma de contagem informada (dias úteis vs corridos)
- [ ] Prazos com menos de 3 dias úteis destacados como CRÍTICO
- [ ] Prazos entre 3-5 dias úteis destacados como URGENTE
- [ ] Prazos vencidos identificados e sinalizados como VENCIDO
- [ ] Base legal de cada prazo citada

## 6. Riscos (5 Níveis)
### Nível 1 — Existência do Processo
- [ ] Há petição inicial válida?
- [ ] Houve citação válida do réu?
- [ ] O órgão julgador tem jurisdição?

### Nível 2 — Validade dos Pressupostos
- [ ] Competência absoluta verificada (matéria, função, pessoa)
- [ ] Competência relativa verificada (territorial, valor)
- [ ] Partes têm capacidade processual
- [ ] Advogados com OAB regular e procuração válida
- [ ] Petição inicial atende art. 319, CPC/2015

### Nível 3 — Condições da Ação
- [ ] Legitimidade ativa e passiva verificadas
- [ ] Interesse processual verificado (utilidade + necessidade)
- [ ] Possibilidade jurídica do pedido verificada

### Nível 4 — Objeções Substanciais
- [ ] Prescrição verificada — data do último ato interruptivo identificado
- [ ] Decadência verificada — prazo improrrogável analisado
- [ ] Coisa julgada verificada — processo anterior com mesmo objeto?
- [ ] Litispendência verificada — processo idêntico em curso?
- [ ] Perempção verificada — três extinções por abandono?

### Nível 5 — Regularidade Formal
- [ ] Citações e intimações válidas
- [ ] Prazos observados
- [ ] Documentos essenciais juntados (art. 320, CPC/2015)
- [ ] Procuração com poderes adequados
- [ ] Recolhimento de custas e honorários

## 7. Qualidade do Relatório
- [ ] Alertas CRÍTICOS no TOPO (antes de qualquer outro dado)
- [ ] Dados apresentados em tabelas (não em parágrafos corridos)
- [ ] Base legal de cada prazo citada
- [ ] Fatos, fundamentos e pedidos claramente separados
- [ ] Disclaimer de não-parecer presente ao final
- [ ] Data da análise registrada
- [ ] Número do processo no cabeçalho

---

## Checklist Específico — Análise de Sentença

- [ ] Três partes identificadas: relatório, fundamentação, dispositivo (art. 489, CPC/2015)
- [ ] Resultado do dispositivo claro: procedente / procedente em parte / improcedente / extinção sem mérito
- [ ] Cada pedido mapeado com seu resultado
- [ ] Condenações detalhadas: valor principal, juros, correção, honorários, custas
- [ ] Prazo para embargos de declaração calculado (5 dias úteis — art. 1.023)
- [ ] Prazo para apelação calculado (15 dias úteis — art. 1.003, §5º)
- [ ] Pontos passíveis de embargos identificados (omissão, contradição, obscuridade)
- [ ] Pontos passíveis de apelação identificados

## Checklist Específico — Minutas

- [ ] Prazo verificado antes de iniciar — alertar se < 3 dias úteis
- [ ] Cabimento do recurso verificado (rol taxativo art. 1.015 para agravo)
- [ ] Estrutura padrão seguida (conforme CPC/2015)
- [ ] Pontos para o advogado sinalizados com ⚠️ REVISAR / 📋 COMPLETAR / ⚖️ ESTRATÉGIA
- [ ] Documentos a juntar listados com 📄 DOCUMENTO
- [ ] Aviso de rascunho presente na entrega da minuta
- [ ] Versão salva com nomenclatura: {tipo}_v{N}_{YYYY-MM-DD}.md

---

*Analista Processual Squad v1.1.0 — AIOX Squads*
