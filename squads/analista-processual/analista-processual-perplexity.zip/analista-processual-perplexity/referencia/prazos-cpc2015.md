# Referência de Prazos — CPC/2015 e Legislação Especial

> Analista Processual Squad v1.1.0 | Referência normativa para cálculo de prazos

---

## Regra Geral de Contagem (CPC/2015)

```
Lei: Art. 219, CPC/2015
Regra: DIAS ÚTEIS (exclui sábados, domingos e feriados)
Vigência: Processos distribuídos após 18/03/2016

Intimação em:     Dia X
Início do prazo:  Dia X + 1 dia útil (art. 224)
Prazo de:         N dias úteis
Vencimento:       Dia X + 1 + N dias úteis

Se vencer em dia não útil → prorroga para o próximo dia útil (art. 224, §1º)
```

---

## Prazos Processuais CPC/2015

### Petições e Respostas
| Ato Processual | Prazo | Tipo | Base Legal |
|----------------|-------|------|-----------|
| Contestação | 15 | úteis | Art. 335, CPC/2015 |
| Réplica (impugnação à contestação) | 15 | úteis | Art. 351, CPC/2015 |
| Manifestação genérica | 15 | úteis | Art. 218, §3º, CPC/2015 |
| Reconvenção | junto à contestação | — | Art. 343, CPC/2015 |
| Exceção de incompetência relativa | junto à contestação | — | Art. 64, CPC/2015 |
| Impugnação ao valor da causa | junto à contestação | — | Art. 293, CPC/2015 |

### Recursos
| Recurso | Prazo | Tipo | Base Legal |
|---------|-------|------|-----------|
| Apelação | 15 | úteis | Art. 1.003, §5º, CPC/2015 |
| Agravo de Instrumento | 15 | úteis | Art. 1.003, §5º, CPC/2015 |
| Agravo Interno | 15 | úteis | Art. 1.021, CPC/2015 |
| Embargos de Declaração | **5** | úteis | Art. 1.023, CPC/2015 |
| Recurso Ordinário | 15 | úteis | Art. 1.003, §5º, CPC/2015 |
| Recurso Especial (STJ) | 15 | úteis | Art. 1.003, §5º, CPC/2015 |
| Recurso Extraordinário (STF) | 15 | úteis | Art. 1.003, §5º, CPC/2015 |
| Embargos de Divergência | 15 | úteis | Art. 1.043, §4º, CPC/2015 |

### Execução e Cumprimento de Sentença
| Ato | Prazo | Tipo | Base Legal |
|-----|-------|------|-----------|
| Pagamento voluntário (cumprimento sentença) | 15 | úteis | Art. 523, CPC/2015 |
| Impugnação ao cumprimento de sentença | 15 | úteis | Art. 525, CPC/2015 |
| Embargos à execução de título extrajudicial | 15 | úteis | Art. 915, CPC/2015 |
| Exceção de pré-executividade | sem prazo específico | — | construção jurisprudencial |

### Tutelas de Urgência
| Ato | Prazo | Tipo | Base Legal |
|-----|-------|------|-----------|
| Manifestação sobre tutela antecipada | 15 | úteis | Art. 300 c/c art. 218, §3º |
| Agravo de instrumento (contra tutela) | 15 | úteis | Art. 1.015, I, CPC/2015 |

---

## Exceções — Dias Corridos

| Situação | Base Legal |
|----------|-----------|
| Habeas Corpus | Art. 5º, LXVIII, CF/88 |
| Prazos processuais penais em geral | CPP |
| Alguns prazos da Lei de Execução Fiscal | Lei 6.830/1980 |
| Prazo para habilitação em falência | Lei 11.101/2005 |

---

## Suspensão de Prazos

| Situação | Período | Base Legal |
|----------|---------|-----------|
| Férias forenses | 1-31 janeiro / 1-31 julho | Art. 220, CPC/2015 |
| Recesso natalino (STJ/STF) | ~20 dez a ~20 jan | Regimentos internos |
| Acordo entre as partes | Até 6 meses | Art. 313, II, CPC/2015 |
| Impedimento do juiz | Durante o período | Art. 313, I, CPC/2015 |
| Calamidade pública | Por deliberação do CNJ | Resoluções CNJ |

---

## Prazos para Entes Públicos e Especiais

| Sujeito | Prazo | Base Legal |
|---------|-------|-----------|
| Fazenda Pública — contestação | 30 dias úteis | Art. 183, CPC/2015 |
| Fazenda Pública — recursos | 30 dias úteis | Art. 183, CPC/2015 |
| Ministério Público — atos processuais | 30 dias úteis | Art. 180, CPC/2015 |
| Defensoria Pública — atos processuais | 30 dias úteis | Art. 186, CPC/2015 |
| Litisconsortes com advogados diferentes | em dobro | Art. 229, CPC/2015 |

> ⚠️ CPC/2015 **aboliu** o prazo em quádruplo para contestar da Fazenda e o prazo em dobro para recorrer (previstos no CPC/1973). Agora Fazenda tem prazo simples multiplicado por 2 para todos os atos.

---

## Prazos Prescricionais Comuns

### Código Civil (CC/2002)
| Pretensão | Prazo | Base Legal |
|-----------|-------|-----------|
| Reparação civil (regra geral) | 3 anos | Art. 206, §3º, V |
| Cobrança de dívidas (regra geral) | 5 anos | Art. 206-A |
| Responsabilidade civil contratual | 3 anos | Art. 205 c/c art. 206 |
| Petição de herança | 10 anos | Art. 205 |
| Invalidade de atos jurídicos | 4 anos (relativa) / 10 anos (absoluta) | Arts. 178/179 |

### CLT (Trabalhista)
| Pretensão | Prazo | Base Legal |
|-----------|-------|-----------|
| Créditos trabalhistas (em vigor) | 5 anos (máx. 2 pós-contrato) | Art. 7º, XXIX, CF/88 |
| FGTS | 30 anos (antes do STF RE 709.212) / 5 anos (após) | RE 709.212 STF |

### CDC (Consumerista)
| Pretensão | Prazo | Base Legal |
|-----------|-------|-----------|
| Reparação de danos (fato do produto/serviço) | 5 anos | Art. 27, CDC |

### CTN (Tributário)
| Pretensão | Prazo | Base Legal |
|-----------|-------|-----------|
| Decadência do crédito tributário | 5 anos | Art. 173, CTN |
| Prescrição da execução fiscal | 5 anos | Art. 174, CTN |

---

## Contagem de Prazos — Exemplo Prático

```
Situação: Intimação publicada no DJe em 10/03/2026 (segunda-feira)
Prazo: Contestação — 15 dias úteis

Passo 1 — Identificar o dia de publicação:
  10/03/2026 (segunda)

Passo 2 — Início do prazo = D+1 útil:
  11/03/2026 (terça) ← INÍCIO DA CONTAGEM

Passo 3 — Contar 15 dias úteis (excluindo sáb, dom, feriados):
  Dia 01: 11/03 (ter)
  Dia 02: 12/03 (qua)
  Dia 03: 13/03 (qui)
  Dia 04: 16/03 (seg) ← pulou sáb/dom
  Dia 05: 17/03 (ter)
  Dia 06: 18/03 (qua)
  Dia 07: 19/03 (qui)
  Dia 08: 20/03 (sex)
  Dia 09: 23/03 (seg)
  Dia 10: 24/03 (ter)
  Dia 11: 25/03 (qua)
  Dia 12: 26/03 (qui)
  Dia 13: 27/03 (sex)
  Dia 14: 30/03 (seg)
  Dia 15: 31/03 (ter) ← VENCIMENTO

Resultado: Contestação deve ser protocolada até 31/03/2026
```

---

## Alertas de Urgência

| Nível | Prazo Restante | Ação |
|-------|---------------|------|
| ⬛ VENCIDO | 0 dias | Verificar imediatamente — possível perda de prazo |
| 🔴 CRÍTICO | 1-3 dias úteis | Providenciar ato imediatamente |
| 🟡 URGENTE | 4-5 dias úteis | Priorizar — preparar o ato |
| 🟠 ATENÇÃO | 6-10 dias úteis | Planejar e iniciar elaboração |
| 🟢 OK | >10 dias úteis | Monitorar normalmente |

---

*Referência: CPC/2015 (Lei 13.105/2015) | CC/2002 | CLT | CDC | CTN*
*Analista Processual Squad v1.1.0 — AIOX Squads*
