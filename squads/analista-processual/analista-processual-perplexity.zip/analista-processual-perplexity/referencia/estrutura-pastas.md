# Estrutura de Pastas — Sistema de Arquivos do Squad

> Analista Processual Squad v1.1.0
> Raiz: `K:\Meu Drive\Processos_Judiciais_IA\`

---

## Visão Geral

```
K:\Meu Drive\Processos_Judiciais_IA\
│
├── 1. Execução Compulsória Extrajudicial\     ← Demanda principal
│   ├── 01_Processo\
│   │   └── 1234567-89.2024.8.26.0100.pdf     ← Arquivo de identificação (formato CNJ)
│   ├── 02_Peticoes\
│   ├── 03_Decisoes\
│   ├── 04_Documentos_Probatorios\
│   ├── 05_Intimacoes\
│   ├── 06_Minutas\                            ← Minutas geradas pelo squad
│   ├── 07_Cronograma_Prazos\
│   ├── 08_Relatorios_Analise\
│   ├── 09_Correspondencias\
│   ├── 10_Notas_Internas\
│   └── 1.1 Ação de Imissão na Posse\         ← Subpasta correlata
│       ├── 01_Processo\
│       ├── 02_Peticoes\
│       └── ... (mesma estrutura)
│
├── 2. Ação de Cobrança — Contrato XYZ\
│   └── ... (mesma estrutura)
│
└── Biblioteca de Conhecimento\
    ├── _indice.yaml                           ← Índice mestre mantido pelo squad
    ├── 01_Direito_Civil\
    │   ├── 01_Obrigacoes_e_Contratos\
    │   ├── 02_Responsabilidade_Civil\
    │   ├── 03_Direito_de_Familia\
    │   ├── 04_Direito_das_Sucessoes\
    │   ├── 05_Posse_e_Propriedade\
    │   └── 06_Direitos_Reais\
    ├── 02_Direito_Processual_Civil\
    │   ├── 01_CPC_2015_Comentado\
    │   ├── 02_Procedimentos_Especiais\
    │   ├── 03_Recursos\
    │   ├── 04_Execucao_Civil\
    │   ├── 05_Tutelas_de_Urgencia\
    │   └── 06_Provas\
    ├── 03_Direito_Trabalhista\
    ├── 04_Direito_Tributario_e_Fiscal\
    ├── 05_Direito_Administrativo\
    ├── 06_Direito_Constitucional\
    ├── 07_Direito_do_Consumidor\
    ├── 08_Direito_Empresarial\
    ├── 09_Direito_Imobiliario\
    ├── 10_Direito_Previdenciario\
    ├── 11_Direito_Penal\
    ├── 12_Jurisprudencia\
    │   ├── 01_STF\
    │   ├── 02_STJ\
    │   ├── 03_TST\
    │   ├── 04_TRFs\
    │   ├── 05_TJs\
    │   ├── 06_TRTs\
    │   ├── 07_Sumulas_e_Teses\
    │   └── 08_IAC_e_IRDR\
    ├── 13_Doutrina_e_Livros\
    ├── 14_Modelos_e_Minutas\
    │   ├── 01_Peticoes_Iniciais\
    │   ├── 02_Contestacoes\
    │   ├── 03_Recursos\
    │   ├── 04_Manifestacoes_e_Requerimentos\
    │   ├── 05_Contratos_e_Notificacoes\
    │   └── 06_Pareceres_e_Relatorios\
    └── 15_Pesquisas_e_Analises\
        ├── 01_Pesquisas_Tematicas\
        ├── 02_Analises_Comparativas\
        ├── 03_Memorandos_Internos\
        └── 04_Notas_Tecnicas\
```

---

## Convenções de Nomenclatura

| Tipo | Formato | Exemplo |
|------|---------|---------|
| Demanda principal | `{N}. {Nome da Demanda}` | `3. Mandado de Segurança — Licitação` |
| Subpasta correlata | `{N}.{S} {Nome}` | `3.1 Cautelar Inominada` |
| Arquivo do processo | `NNNNNNN-DD.AAAA.J.TT.OOOO.pdf` | `0001234-56.2024.8.26.0100.pdf` |
| Minuta | `{tipo}_v{N}_{YYYY-MM-DD}.md` | `contestacao_v1_2026-03-14.md` |
| Relatório | `relatorio_{tipo}_{YYYY-MM-DD}.md` | `relatorio_prazos_2026-03-14.md` |

---

## Regras de Acesso Cruzado

| Tipo de Acesso | Permitido | Observação |
|----------------|-----------|-----------|
| Pasta da demanda ativa | ✅ | Acesso total |
| Subpastas correlatas | ✅ | Para contexto complementar |
| Biblioteca de Conhecimento | ✅ | Sempre consultada antes de fontes externas |
| Outras demandas | ⚠️ | Requer autorização explícita do usuário |

---

## Nota sobre o Formato CNJ

O arquivo no formato `NNNNNNN-DD.AAAA.J.TT.OOOO.pdf` serve **apenas para identificar** que o arquivo é o processo judicial principal.

**Todos os demais arquivos presentes nas pastas da demanda** — contratos, notificações, decisões, documentos probatórios — são igualmente válidos e devem ser considerados para análise.

### Decodificação do Número CNJ
```
NNNNNNN    = 7 dígitos do número de ordem
DD         = 2 dígitos verificadores
AAAA       = Ano de distribuição
J          = Justiça (1=Federal, 2=Estadual, 3=Militar, 5=Trabalho, 6=Eleitoral, 8=STJ, 9=STF)
TT         = Tribunal (02=TRF2, 26=TJSP, etc.)
OOOO       = Origem/Vara (4 dígitos)

Exemplo: 0001234-56.2024.8.26.0100
  Número: 0001234
  Dígitos: 56
  Ano: 2024
  Justiça: 8 (Estadual — TJSP)
  Tribunal: 26 (TJSP)
  Vara: 0100
```

---

*Analista Processual Squad v1.1.0 — AIOX Squads*
